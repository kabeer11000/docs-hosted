//	Include the neccessary css, js files
//ayoola.files.loadJsObjectCss( 'div' );
//ayoola.files.loadJsObject( 'events' );

//	Class Begins
ayoola.form.element =
{
	elements: {  }, // Elements in the form
				
	//	Sets the post type to a new value
	init: function( formObject )
	{
		
	}
}
